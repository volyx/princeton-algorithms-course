import edu.princeton.cs.algs4.StdOut;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {

    private Node<Item> first;
    private Node<Item> last;

    // construct an empty deque
    public Deque() {
    }

    // is the deque empty?
    public boolean isEmpty() {
        return first == null;
    }

    // return the number of items on the deque
    public int size() {
        int size = 0;

        Node<Item> current = first;

        while (current != null) {
            current = current.next;
            size++;
        }
        return size;
    }

    // add the item to the front
    public void addFirst(Item item) {

        if (item == null) {
            throw new IllegalArgumentException();
        }

        Node<Item> newNode = new Node<>();
        newNode.value = item;
        if (isEmpty()) {
            this.first = newNode;
            last = this.first;
            return;
        }

        Node<Item> oldFirst = this.first;
        this.first = newNode;
        this.first.next = oldFirst;
    }

    // add the item to the back
    public void addLast(Item item) {

        if (item == null) {
            throw new IllegalArgumentException();
        }

        final Node<Item> newNode = new Node<>();
        newNode.value = item;

        if (isEmpty()) {
            this.first = newNode;

            last = this.first;
            return;
        }

        Node<Item> current = this.first;
        while (current != null) {
            current = current.next;
        }

        Node<Item> oldLast = last;
        last = newNode;
        last.value = item;
        oldLast.next = last;
    }

    // remove and return the item from the front
    public Item removeFirst() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        Node<Item> oldFirst = first;
        first = first.next;
        return oldFirst.value;
    }

    // remove and return the item from the back
    public Item removeLast() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }

        Node<Item> fast = first;
        Node<Item> slow = first;
        while (fast != null && fast.next != null) {
            fast = fast.next.next;
            slow = slow.next;
        }

        Node<Item> previousLast = slow;
        Node<Item> oldLast = last;
        last = previousLast;
        last.next = null;
        return oldLast.value;
    }

    // return an iterator over items in order from front to back
    public Iterator<Item> iterator() {

        if (isEmpty()) {
            return new Iterator<Item>() {
                public boolean hasNext() {
                    return false;
                }

                public Item next() {
                    throw new NoSuchElementException();
                }

                public void remove() {
                    throw new UnsupportedOperationException();
                }
            };
        }

        return new Iterator<Item>() {
            private Node<Item> current = first;

            public boolean hasNext() {
                return current != null;
            }

            public Item next() {
                Node<Item> oldCurrent = current;
                current = current.next;
                return oldCurrent.value;
            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    // unit testing (required)
    public static void main(String[] args) {

        Deque<Integer> deque = new Deque<>();

        deque.addFirst(3);
        deque.addFirst(2);
        deque.addFirst(1);

        for (Integer value : deque) {
            StdOut.println(value);
        }

        Integer removedLast = deque.removeLast();

        StdOut.println(removedLast);

        for (Integer value : deque) {
            StdOut.println(value);
        }

        deque.addFirst(-3);
        deque.addFirst(-2);
        deque.addFirst(-1);

        StdOut.println();

        for (Integer value : deque) {
            StdOut.println(value);
        }

        deque.addLast(30);
        deque.addLast(20);
        deque.addLast(10);

        StdOut.println();

        for (Integer value : deque) {
            StdOut.println(value);
        }

        Integer removeFirst = deque.removeFirst();
        deque.removeFirst();
        deque.removeFirst();

        StdOut.println();

        for (Integer value : deque) {
            StdOut.println(value);
        }

        deque.removeFirst();
        deque.removeFirst();
        deque.removeFirst();
        deque.removeFirst();
        deque.removeFirst();

        for (Integer value : deque) {
            StdOut.println(value);
        }

        deque.addLast(21);
        deque.addLast(22);
        deque.addLast(23);

        StdOut.println();

        for (Integer value : deque) {
            StdOut.println(value);
        }
    }

    private class Node<NodeItem> {

        private NodeItem value;
        private Node<NodeItem> next;
    }
}
