import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FastCollinearPoints {
    private final List<LineSegment> segments = new ArrayList<>();

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {
        if (points == null) {
            throw new IllegalArgumentException("points is null");
        }
        if (points.length == 0) {
            throw new IllegalArgumentException("points are empty");
        }

        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) {
                throw new IllegalArgumentException("point at index " + i + " is null");
            }
            for (int j = 0; j < i; j++) {
                if (points[j].compareTo(points[i]) == 0) {
                    throw new IllegalArgumentException();
                }
            }
        }

        Point[] sortedPoints = Arrays.copyOf(points, points.length);

        for (int i = 0; i < points.length; i++) {
            final Point origin = points[i];

            Arrays.sort(sortedPoints);
            Arrays.sort(sortedPoints, origin.slopeOrder());

            final List<LineSegment> lineSegments = findSegments(origin, sortedPoints);

            if (!lineSegments.isEmpty()) {
                this.segments.addAll(lineSegments);
            }
        }
    }
    //
    // 0 000011112222

    private List<LineSegment> findSegments(Point origin, Point[] sortedPoints) {

        final List<LineSegment> originSegments = new ArrayList<>();
        int start = 0;
        int n = sortedPoints.length;
        while (start < n) {
            List<Point> line = new ArrayList<>();
            line.add(origin);
            double findAngle = origin.slopeTo(sortedPoints[start]);
            line.add(sortedPoints[start]);

            while (start < n - 1
                    && origin.slopeTo(sortedPoints[start + 1]) == findAngle) {
                line.add(sortedPoints[start + 1]);
                start++;
            }

            if (line.size() > 3) {
                Point startPoint = line.get(0);
                Point endPoint = line.get(line.size() - 1);
                if (origin.equals(startPoint)) {
                    originSegments.add(new LineSegment(startPoint, endPoint));
                }
            }
            start++;
        }
        return originSegments;
    }

    // the number of line segments
    public int numberOfSegments() {
        return segments.size();
    }

    // the line segments
    public LineSegment[] segments() {
        return segments.toArray(new LineSegment[0]);
    }


    public static void main(String[] args) {

        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }

}
