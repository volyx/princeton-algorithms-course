import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class Solver {

    private final List<Board> solution;

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial == null) {
            throw new IllegalArgumentException();
        }

        this.solution = solve(initial);
    }

    private List<Board> solve(Board initial) {

        MinPQ<SearchNode> minPQ = new MinPQ<>((o1, o2) -> {
            final int movesCompare = Integer.compare(o1.moves, o2.moves);
            if (movesCompare != 0) {
                return movesCompare;
            }
            // int hammingCompare = Integer.compare(o1.board.hamming(), o2.board.hamming());
            // if (hammingCompare != 0) {
            //     return hammingCompare;
            // }
            return Integer
                    .compare(o1.moves + o1.board.manhattan(), o2.moves + o2.board.manhattan());
        });

        minPQ.insert(new SearchNode(null, initial, 0));

        while (!minPQ.isEmpty()) {
            final SearchNode searchNode = minPQ.delMin();

            if (searchNode.board.isGoal()) {
                return buildShortestPath(searchNode);
            }

            for (Board childBoard : searchNode.board.neighbors()) {

                if (searchNode.previous != null && searchNode.previous.board.equals(childBoard)) {
                    continue;
                }

                SearchNode childSearchNode = new SearchNode(searchNode, childBoard,
                                                            searchNode.moves + 1);

                minPQ.insert(childSearchNode);
            }
        }

        return null;
    }

    private List<Board> buildShortestPath(SearchNode searchNode) {
        List<Board> boards = new ArrayList<>();
        SearchNode currentNode = searchNode;
        while (currentNode.previous != null) {
            boards.add(currentNode.board);
            currentNode = currentNode.previous;
        }
        Collections.reverse(boards);
        return boards;
    }

    // is the initial board solvable? (see below)
    public boolean isSolvable() {
        return solution != null;
    }

    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
        if (!isSolvable()) {
            return -1;
        }
        return solution.size();
    }

    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
        return solution;
    }

    private static class SearchNode implements Comparable<SearchNode> {

        private final SearchNode previous;
        private final Board board;
        private final int moves;

        private SearchNode(SearchNode previous, Board board, int moves) {
            this.previous = previous;
            this.board = board;
            this.moves = moves;
        }

        public int compareTo(SearchNode that) {
            return Integer.compare(this.moves, that.moves);
        }

        public boolean equals(Object object) {
            if (this == object) return true;
            if (object == null || getClass() != object.getClass()) return false;
            SearchNode that = (SearchNode) object;
            return moves == that.moves &&
                    Objects.equals(previous, that.previous) &&
                    Objects.equals(board, that.board);
        }

        public int hashCode() {
            return Objects.hash(previous, board, moves);
        }
    }

    public static void main(String[] args) {

        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                tiles[i][j] = in.readInt();
        Board initial = new Board(tiles);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }

}
