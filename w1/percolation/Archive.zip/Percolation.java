import edu.princeton.cs.algs4.QuickUnionUF;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

import java.util.Arrays;

public class Percolation {

    private final int n;

    private int[][] grid;

    private int numberOfOpenSites;

    private final UF uf;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) throw new IllegalStateException();
        this.n = n;
        this.uf = new WeightedQuickUnionUFImpl((n + 2) * (n + 2));
        this.grid = new int[n + 2][n + 2];

        // virtual top and bottom
        for (int i = 0; i < grid.length; i++) {
            openVirtual(0, i);
            openVirtual(n + 1, i);
        }

        this.numberOfOpenSites = 0;
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        checkIndex(row, "row is ");
        checkIndex(col, "col is ");

        openVirtual(row, col);
    }

    // opens the site (row, col) if it is not open already
    private void openVirtual(int row, int col) {

        if (!isOpenVirtual(row, col)) {
            grid[row][col] = 1;
            this.numberOfOpenSites++;

            // top
            if (row - 1 >= 0 && isOpenVirtual(row - 1, col)) {
                uf.union(xyTo1D(row, col), xyTo1D(row - 1, col));
            }

            // right
            if (col + 1 < grid.length && isOpenVirtual(row, col + 1)) {
                uf.union(xyTo1D(row, col), xyTo1D(row, col + 1));
            }

            // down
            if (row + 1 < grid.length && isOpenVirtual(row + 1, col)) {
                uf.union(xyTo1D(row, col), xyTo1D(row + 1, col));
            }

            // left
            if (col - 1 >= 0 && isOpenVirtual(row, col - 1)) {
                uf.union(xyTo1D(row, col), xyTo1D(row, col - 1));
            }
        }
    }

    private int xyTo1D(int p, int q) {
        return (n + 2) * p + q;
    }

    private void checkIndex(int col, String s) {
        if (col < 1 || col > n) {
            throw new IllegalStateException(s + col);
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        checkIndex(row, "row is ");
        checkIndex(col, "col is ");
        return isOpenVirtual(row, col);
    }

    // is the site (row, col) open?
    private boolean isOpenVirtual(int row, int col) {
        return grid[row][col] == 1;
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        checkIndex(row, "row is ");
        checkIndex(col, "col is ");
        return uf.connected(xyTo1D(0, 0), xyTo1D(row, col));
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return this.numberOfOpenSites;
    }

    // does the system percolate?
    public boolean percolates() {
        return uf.connected(xyTo1D(0, 0), xyTo1D(n + 1, 0));
    }

    // test client (optional)
    public static void main(String[] args) {

        Percolation percolation = new Percolation(5);

        percolation.open(1, 1);
        percolation.open(2, 1);
        percolation.open(3, 1);
        percolation.open(4, 1);
        percolation.open(5, 1);

        for (int i = 0; i < percolation.grid.length; i++) {
            StdOut.println(Arrays.toString(percolation.grid[i]));
        }

        for (int i = 0; i < percolation.grid.length; i++) {
            for (int j = 0; j < percolation.grid.length; j++) {
                StdOut.print(percolation.xyTo1D(i, j) + ", ");
            }
            StdOut.println();
        }

        StdOut.println("connected 1,1 2,1" + percolation.uf
                .connected(percolation.xyTo1D(1, 1), percolation.xyTo1D(2, 1)));
        StdOut.println("connected 2,1 3,1" + percolation.uf
                .connected(percolation.xyTo1D(2, 1), percolation.xyTo1D(3, 1)));
        StdOut.println("connected 3,1 4,1" + percolation.uf
                .connected(percolation.xyTo1D(3, 1), percolation.xyTo1D(4, 1)));
        StdOut.println("connected 4,1 5,1" + percolation.uf
                .connected(percolation.xyTo1D(4, 1), percolation.xyTo1D(5, 1)));
        StdOut.println("connected 1,1 5,1" + percolation.uf
                .connected(percolation.xyTo1D(1, 1), percolation.xyTo1D(5, 1)));

        StdOut.println("connected 0,0 0,1" + percolation.uf
                .connected(percolation.xyTo1D(0, 0), percolation.xyTo1D(0, 1)));

        StdOut.println("connected 0,0 1,1" + percolation.uf
                .connected(percolation.xyTo1D(0, 0), percolation.xyTo1D(1, 1)));

        StdOut.println("connected 0,0 6,1" + percolation.uf
                .connected(percolation.xyTo1D(0, 0), percolation.xyTo1D(6, 1)));

    }

    private interface UF {

        boolean connected(int p, int q);

        void union(int p, int q);
    }

    private class QuickUnionFindUFImpl implements Percolation.UF {

        private final QuickUnionUF uf;

        public QuickUnionFindUFImpl(int n) {
            this.uf = new QuickUnionUF(n);
        }

        public int count() {
            return uf.count();
        }

        public int find(int p) {
            return uf.find(p);
        }

        public boolean connected(int p, int q) {
            return uf.find(p) == uf.find(q);
        }

        public void union(int p, int q) {
            uf.union(p, q);
        }
    }

    private class WeightedQuickUnionUFImpl implements Percolation.UF {

        private final WeightedQuickUnionUF uf;

        private WeightedQuickUnionUFImpl(int n) {
            this.uf = new WeightedQuickUnionUF(n);
        }

        public int count() {
            return uf.count();
        }

        public int find(int p) {
            return uf.find(p);
        }

        public boolean connected(int p, int q) {
            return uf.find(p) == uf.find(q);
        }

        public void union(int p, int q) {
            uf.union(p, q);
        }
    }
}
